/*******************************************************************************
 * SCHEDULER - MODO AUTÓNOMO (MERGED)
 * - Los robots eligen sus tareas (Pull) en lugar de recibirlas (Push).
 * - Prioridad URGENTE gestionada por publicación.
 * - Soporte para fases de salida y gestión de estanterías inteligente.
 ******************************************************************************/

/* --- Capacidades de Robots (Para validaciones internas si fueran necesarias) --- */
robot_capacity(robot_light,  10,  1, 1, 3).
robot_capacity(robot_medium, 30,  1, 2, 2).
robot_capacity(robot_heavy,  100, 2, 3, 1).
robot_capacity(robot_heavy_2, 100, 2, 3, 1).

robot_status(robot_light,  idle).
robot_status(robot_medium, idle).
robot_status(robot_heavy,  idle).
robot_status(robot_heavy_2, idle).

/* --- Configuración de Estanterías --- */
shelf_data("shelf_1", 50, 8, 0, 0).
shelf_data("shelf_2", 50, 8, 0, 0).
shelf_data("shelf_3", 50, 8, 0, 0).
shelf_data("shelf_4", 50, 8, 0, 0).
shelf_data("shelf_5", 100, 12, 0, 0).
shelf_data("shelf_6", 100, 12, 0, 0).
shelf_data("shelf_7", 100, 12, 0, 0).
shelf_data("shelf_8", 200, 20, 0, 0).
shelf_data("shelf_9", 200, 20, 0, 0).

shelf_allows_type("shelf_1", "urgent").
shelf_allows_type("shelf_5", "urgent").
shelf_allows_type("shelf_8", "urgent").
shelf_allows_type("shelf_2", "standard"). shelf_allows_type("shelf_2", "fragile").
shelf_allows_type("shelf_3", "standard"). shelf_allows_type("shelf_3", "fragile").
shelf_allows_type("shelf_4", "standard"). shelf_allows_type("shelf_4", "fragile").
shelf_allows_type("shelf_6", "standard"). shelf_allows_type("shelf_6", "fragile").
shelf_allows_type("shelf_7", "standard"). shelf_allows_type("shelf_7", "fragile").
shelf_allows_type("shelf_9", "standard"). shelf_allows_type("shelf_9", "fragile").

/* Regla de validación de hueco */
shelf_fits(ShelfId, Weight, Area, Type) :-
    shelf_data(ShelfId, MaxW, MaxV, CurW, CurV) &
    CurW + Weight <= MaxW &
    CurV + Area <= MaxV &
    shelf_allows_type(ShelfId, Type).

/* Estadísticas */
stat_received(0). stat_assigned(0). stat_completed(0). stat_errors(0).

!start.

+!start : true <-
    .print("[Scheduler] ⭐ MODO AUTÓNOMO OPERATIVO - Publicando para robots");
    !main_loop.

/* ========== CICLO DE REVISIÓN (Cada 500ms) ========== */
+!main_loop <-
    .wait(500);
    !check_and_broadcast;
    !main_loop.

+!check_and_broadcast <-
    !broadcast_urgents;
    !broadcast_normals;
    .abolish(skip(_)).

/* Publicar Urgentes */
+!broadcast_urgents : pending(CId, W, H, Weight, "urgent") & not skip(CId) <-
    .broadcast(tell, pending_container(CId, W, H, Weight, "urgent"));
    +skip(CId);
    !broadcast_urgents.
+!broadcast_urgents <- true.

/* Publicar Normales */
+!broadcast_normals : pending(CId, W, H, Weight, Type) & Type \== "urgent" & not skip(CId) <-
    .broadcast(tell, pending_container(CId, W, H, Weight, Type));
    +skip(CId);
    !broadcast_normals.
+!broadcast_normals <- true.

/* ========== RECEPCIÓN DE CONTENEDORES ========== */
+new_container(CId) : not pending(CId, _, _, _, _) <-
    ?stat_received(N); -stat_received(N); +stat_received(N+1);
    get_container_info(CId).

+container_info(CId, W, H, Weight, Type) : true <-
    -container_info(CId, W, H, Weight, Type);

    // Determinar grupo para fase de salida
    if (Type == "urgent") { Group = urgent; } else { Group = nonurgent; }

    if (output_phase(Group)) {
        .print("[Scheduler] 🚫 RECHAZADO (Fase Salida): ", CId);
    } else {
        .print("[Scheduler] 📥 NUEVO: ", CId, " (", Type, ")");
        +pending(CId, W, H, Weight, Type);
        .send(supervisor, tell, container_counted(CId, W, H, Weight, Type));
        !check_and_broadcast;
    }.

/* ========== GESTIÓN DE TAREAS Y ESTANTERÍAS ========== */

/* Los robots pedirán una estantería cuando decidan tomar un contenedor */
+!find_best_shelf(CId, W, H, Weight, Type, ShelfId)
    : shelf_fits("shelf_1", Weight, W*H, Type) <- ShelfId = "shelf_1".
+!find_best_shelf(CId, W, H, Weight, Type, ShelfId)
    : shelf_fits("shelf_2", Weight, W*H, Type) <- ShelfId = "shelf_2".
+!find_best_shelf(CId, W, H, Weight, Type, ShelfId)
    : shelf_fits("shelf_3", Weight, W*H, Type) <- ShelfId = "shelf_3".
+!find_best_shelf(CId, W, H, Weight, Type, ShelfId)
    : shelf_fits("shelf_4", Weight, W*H, Type) <- ShelfId = "shelf_4".
+!find_best_shelf(CId, W, H, Weight, Type, ShelfId)
    : shelf_fits("shelf_5", Weight, W*H, Type) <- ShelfId = "shelf_5".
+!find_best_shelf(CId, W, H, Weight, Type, ShelfId)
    : shelf_fits("shelf_6", Weight, W*H, Type) <- ShelfId = "shelf_6".
+!find_best_shelf(CId, W, H, Weight, Type, ShelfId)
    : shelf_fits("shelf_7", Weight, W*H, Type) <- ShelfId = "shelf_7".
+!find_best_shelf(CId, W, H, Weight, Type, ShelfId)
    : shelf_fits("shelf_8", Weight, W*H, Type) <- ShelfId = "shelf_8".
+!find_best_shelf(CId, W, H, Weight, Type, ShelfId)
    : shelf_fits("shelf_9", Weight, W*H, Type) <- ShelfId = "shelf_9".

-!find_best_shelf(_, _, _, _, _, _) <- .print("[Scheduler] ❌ ERROR: Sin estantería disponible").

/* Actualizar datos de estantería (llamado por el robot al asignar/recoger) */
+!reserve_shelf_space(ShelfId, Weight, Area) <-
    ?shelf_data(ShelfId, MaxW, MaxV, CurW, CurV);
    -shelf_data(ShelfId, MaxW, MaxV, CurW, CurV);
    +shelf_data(ShelfId, MaxW, MaxV, CurW + Weight, CurV + Area).

+task_complete(CId, Robot)[source(_)] : true <-
    ?stat_completed(NC); -stat_completed(NC); +stat_completed(NC+1);
    .print("[✅ HECHO] ", Robot, " completó ", CId);
    .send(supervisor, tell, task_done(CId, Robot));
    -pending(CId, _, _, _, _);
    .broadcast(untell, pending_container(CId, _, _, _, _)); // Limpiar de los demás robots
    -task_complete(CId, Robot)[source(_)].

/* ========== ERRORES Y REPORTES ========== */
+robot_error(Robot, CId, ErrorType)[source(_)] <-
    .print("[⚠️ ERROR] ", Robot, " reporta: ", ErrorType);
    ?stat_errors(N); -stat_errors(N); +stat_errors(N+1);
    .send(supervisor, tell, error_occurred(Robot, CId, ErrorType));
    -robot_error(Robot, CId, ErrorType)[source(_)].

+!report_shelves <-
    for ( shelf_data(ID, _, _, W, V) ) {
        .send(supervisor, tell, shelf_report(ID, W, V));
    }.

+no_space(Group)[source(supervisor)] : not output_phase(Group) <- +output_phase(Group).
+space_available(Group)[source(supervisor)] <- -output_phase(Group).

+!estado <-
    ?stat_received(R); ?stat_completed(C); ?stat_errors(E);
    .print("[Estado] Recibidos:", R, " | Completados:", C, " | Errores:", E).
